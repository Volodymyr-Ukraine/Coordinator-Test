//
//  NetworkErrorModel.swift
//  ios_party
//
//  Created by Юлия Воротченко on 30.10.2019.
//  Copyright © 2019 Юлия Воротченко. All rights reserved.
//

import Foundation

struct NetworkErrorModel: Decodable {
    let message: String
}
